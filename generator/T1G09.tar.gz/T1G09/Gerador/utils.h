#ifndef __UTILS_H
#define __UTILS_H

double GetTimeSinceProgramStartup(double init_time);

#endif